# CrossGuard — Reactive Liquidity Sentinel

CrossGuard is a dApp built on the **Reactive Network** that monitors cross-chain liquidity pools and automatically triggers rebalancing actions when price or ratio deviations breach thresholds. It demonstrates meaningful use of **Reactive Smart Contracts (RSCs)** with automated, self-sustaining workflows.

## Features
- Reacts to price feed or liquidity events in real time.
- Triggers rebalancing automatically via Reactive callbacks.
- Dashboard for sponsors and developers.
- REACT-powered execution: fund once, run indefinitely.

## Repo Structure
- `contracts/`: Solidity contracts (Origin, RSC, Destination).
- `scripts/`: Deployment and demo scripts.
- `docs/`: Pitch deck, workflow explanation, demo script.
- `frontend/`: App Canvas / App Creator prompt and UI scaffolding.

## Quickstart
1. Clone repo and install dependencies:
   ```bash
   git clone <repo-url>
   cd crossguard-dapp
   npm install
   ```
2. Deploy contracts to Reactive testnet:
   ```bash
   npx hardhat run scripts/deploy.js --network reactive-testnet
   ```
3. Start frontend (if using Next.js scaffold):
   ```bash
   cd frontend && npm run dev
   ```

## License
MIT
