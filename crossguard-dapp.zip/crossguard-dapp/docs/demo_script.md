# Demo Script (3 min)

1. Intro (15s): Problem of cross-chain liquidity drift, need for automation.
2. Show Contracts (30s): Walkthrough of CrossGuardRSC and Rebalancer.
3. Deploy + Fund (30s): Deploy contracts to Reactive testnet, fund with REACT.
4. Trigger Event (45s): Simulate oracle deviation, watch Reactive callback.
5. Rebalance (30s): Show destination contract executing rebalance.
6. Dashboard (30s): Show sponsor + developer panels, REACT top-up.
7. Closing (15s): Emphasize sustainability + social impact.

Total: ~3 minutes
