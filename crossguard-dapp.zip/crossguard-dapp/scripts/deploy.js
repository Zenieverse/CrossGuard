const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  console.log("Deploying with:", deployer.address);

  const Rebalancer = await hre.ethers.getContractFactory("Rebalancer");
  const rebalancer = await Rebalancer.deploy();
  await rebalancer.deployed();
  console.log("Rebalancer deployed to:", rebalancer.address);

  const CrossGuardRSC = await hre.ethers.getContractFactory("CrossGuardRSC");
  const rsc = await CrossGuardRSC.deploy(rebalancer.address, 10); // 10% threshold
  await rsc.deployed();
  console.log("CrossGuardRSC deployed to:", rsc.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
